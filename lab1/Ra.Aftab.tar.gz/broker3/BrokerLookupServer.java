import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

public class BrokerLookupServer
{
  // Setup the hash table of the broker locations that will be shared among threads
  private static final ConcurrentHashMap<String, ArrayList<BrokerLocation>> brokerHash = new ConcurrentHashMap<String, ArrayList<BrokerLocation>>(5);

  public static void main(String[] args) throws IOException
  {
    ServerSocket serverSocket = null;
    boolean listening = true;

    try
    {
      if(args.length == 1)
      {
        serverSocket = new ServerSocket(Integer.parseInt(args[0]));
      } 
      else
      {
        System.err.println("ERROR: Invalid arguments!");
        System.exit(-1);
      }
    } 
    catch (IOException e)
    {
      System.err.println("ERROR: Could not listen on port!");
      System.exit(-1);
    }

    while (listening)
    {
      new BrokerLookupServerThread( serverSocket.accept(), brokerHash ).start();
    }

    serverSocket.close();
  }
}
